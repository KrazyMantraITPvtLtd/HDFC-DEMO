//
//  AppDelegate.h
//  HDFC Demo
//
//  Created by Krazy Mantra IOS on 4/29/16.
//  Copyright © 2016 Krazy Mantra IOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

